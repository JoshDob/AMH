<script>
    import { garden } from "./galleries";
    import GalleryLayout from "./GalleryLayout.svelte";
  </script>
  
  <GalleryLayout images={garden} />