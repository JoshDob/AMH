<script>
    import { botanica3 } from "./galleries";
    import GalleryLayout from "./GalleryLayout.svelte";
  </script>
  
  <GalleryLayout images={botanica3} />