<script>
    import { botanica1 } from "./galleries";
    import GalleryLayout from "./GalleryLayout.svelte";
  </script>
  
  <GalleryLayout images={botanica1} />