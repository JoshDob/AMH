<script>
    import { botanica2 } from "./galleries";
    import GalleryLayout from "./GalleryLayout.svelte";
  </script>
  
  <GalleryLayout images={botanica2} />