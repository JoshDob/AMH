<script>
  import { onMount } from "svelte";
  import { fade } from 'svelte/transition';
  import { elasticOut } from 'svelte/easing';
  import { initMasonry } from "./masonryLayout.js";

  export let images = [];
  let activeImage = 0;

  const getThumbnailSrc = (src) => {
    const [path, ext] = src.split('.');
    return `${path}-T.${ext}`;
  };

  const handleKeydown = (e) => {
    if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
      activeImage = (e.key === "ArrowRight" ? activeImage + 1 : activeImage - 1 + images.length) % images.length;
    }
  };

  onMount(() => {
    // Initialize Masonry, preload images, and add keyboard event listener
    initMasonry('.thumbnails', '.thumbnail', 3);
    images.forEach((image) => {
      new Image().src = getThumbnailSrc(image.src);
      new Image().src = image.src;
    });
    window.addEventListener("keydown", handleKeydown);

    return () => {
      window.removeEventListener("keydown", handleKeydown);
    };
  });
</script>

<div class='layout'> 
  <div class='hero-and-titles' in:fade={{ delay: 500, duration: 1000, easing: elasticOut }}>
    <div class="hero">
      <img role="button" tabindex="0" src={images[activeImage]?.src} alt={images[activeImage]?.title} on:keydown={handleKeydown} />
    </div>
    <div class='titles' in:fade={{ duration: 1000 }}>
      <p>{images[activeImage]?.title}</p>
      <p class='latin'>{images[activeImage]?.latinName}</p>
    </div>
  </div>
  <div class='thumbnail-frame'>
    <div class='thumbnails'>
      {#each images as image, i}
        <div class='thumbnail'>
          <img role="button" src={getThumbnailSrc(image.src)} alt={`Thumbnail of ${image.title}`} on:click={() => activeImage = i} />
        </div>
      {/each}
    </div>
  </div>
</div>


<style>
  .layout {
    display: grid;
    grid-template-areas: "hero thumbnails" "titles thumbnails";
    grid-template-columns: 1fr 248px;
    grid-template-rows: 1fr auto;
  }

  .hero-and-titles {
    grid-area: hero;
    display: grid;
    grid-template-rows: 1fr auto;
  }

  .hero {
    grid-row:1/2;
    display: grid;
    align-items: center;
    justify-items: center;
    
  }

  .hero img {
    object-fit: cover;
    max-width: 100%;
    max-height: 100%;
    cursor: pointer;
  }

  .titles {
  grid-row: 2 / 3;
  display: flex;
  justify-content: space-between;
  background-color: var(--color1);
  color: var(--color2);
  font-family: 'Merriweather', serif;
  font-size: var(--a1);
  font-weight: 300;
  white-space: nowrap;
  }

  .titles p {
    transition: fade-in 1s ease-in-out;
    margin-right: var(--d1); /* Space between titles */
    margin-left: var(--d1);  /* Space between titles */
  }

  .latin {
    font-style: italic;
  }

  .thumbnail-frame {
  grid-area: thumbnails;
  display: grid;
  align-content: center;
  overflow-y: auto;
  max-height: 248px;
}

.thumbnails {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.thumbnail img {
  object-fit: cover;
  height: 80px;
  width: 80px;
  cursor: pointer;
}

 /* Media query for smaller screens */
@media (max-width: 768px) {
  .layout {
    grid-template-areas: 
      "hero"
      "titles"
      "thumbnails";
    grid-template-columns: 1fr;
    grid-template-rows: auto auto auto;
  }

  .hero img {
    height: 480px;
    max-width: 100%;
  }

  .thumbnail-frame {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    overflow-x: auto;
  }
}
</style>
