<div class="archival-prints-page">
  <div class="content">
    <p style="text-align: center; font-style:italic">
      All images are archivally printed as either fine art giclée or metal
      prints. Available as limited editions in a wide range of sizes, prints are
      signed and numbered.
      <br /><br />
    </p>
    <p>
      <strong>Fine Art Giclée</strong><br />
      Printed on a paper that resembles the surface of fine watercolor paper, these
      prints have excellent detail and color reproduction with exceptional depth,
      richness and vibrancy. The prints have white borders and arrive ready to be
      matted and framed. Giclée prints are signed and numbered on the front.
      <br /><br />
      <strong>Metal Prints</strong><br />
      Available with a glossy or pearl finish, metal prints are made through a dye
      sublimation process, where dyes are infused directly into specially coated
      aluminized metal panels. The luminous coating is a waterproof, durable barrier
      against dirt, abrasion and harmful UV rays, thus eliminating the need for protective
      glass. The lightweight metal prints include invisible hangers mounted to the
      back. Metal prints are signed and numbered on the back.
      <br /><br />
      <strong>Small Print Collection</strong><br />
      Choose six images from any gallery for a collection of 8x10 metal or giclée
      prints. Prints are shipped in a handcrafted, archival box in which they can
      be safely stored, presented as a gift or kept until they are displayed.
      <br /><br />
      <strong>Digital Licensing</strong><br />
      Images are available for digital media purposes and reproduction, including
      advertising, editorial or other usage.
      <br /><br />
    </p>

    <p class="contact-info">
      Please contact <a href="mailto:amh@annemariehunter.com"
        >amh@annemariehunter.com</a
      > with questions, including pricing, print size availability or digital usage
      agreements.
    </p>
  </div>
</div>

<style>
  .archival-prints-page {
    display: flex;
    flex-direction: row;
    max-width: 80%;
    text-align: center;
    margin: auto;
    margin-top: var(--c);
  }

  .content p {
    line-height: var(--a1);
    font-size: var(--a);
  }

  .contact-info {
    margin-top: var(--a);
  }

  .content p strong {
    font-size: var(--a);
    text-align: center;
    line-height: var(--b1);
  }
</style>
