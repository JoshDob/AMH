<script>
  import { roses } from "./galleries";
  import GalleryLayout from "./GalleryLayout.svelte";
</script>

<GalleryLayout images={roses} />