<script>
  import { onMount } from "svelte";
  import { fade } from 'svelte/transition';
  import { elasticOut } from 'svelte/easing';
  
  export let images = [];
  let activeImage = 0;
  
  // Helper function to get thumbnail source
  const getThumbnailSrc = (src) => {
    const [path, ext] = src.split('.');
    return `${path}-T.${ext}`;
  };
  
  // Touch event variables
  let xStart = null;
  let yStart = null;
  
  // Handle touch start
  const handleTouchStart = (e) => {
    const firstTouch = e.touches[0];
    xStart = firstTouch.clientX;
    yStart = firstTouch.clientY;
  };
  
  // Handle touch move
  const handleTouchMove = (e) => {
    if (!xStart || !yStart) return;
  
    const xDiff = xStart - e.touches[0].clientX;
    const yDiff = yStart - e.touches[0].clientY;
  
    if (Math.abs(xDiff) > Math.abs(yDiff)) {
      activeImage = xDiff > 0 
        ? (activeImage + 1) % images.length 
        : (activeImage - 1 + images.length) % images.length;
    }
    xStart = null;
    yStart = null;
  };
  
  // Handle keydown for keyboard navigation
  const handleKeydown = (e) => {
    if (e.key === "ArrowRight") {
      activeImage = (activeImage + 1) % images.length;
    } else if (e.key === "ArrowLeft") {
      activeImage = (activeImage - 1 + images.length) % images.length;
    }
  };
  
  // On mount
  onMount(() => {
    // Preload images
    images.forEach((image) => {
      new Image().src = getThumbnailSrc(image.src);
      new Image().src = image.src;
    });
  
    // Add keyboard event listener
    window.addEventListener("keydown", handleKeydown);
  
    // Cleanup
    return () => {
      window.removeEventListener("keydown", handleKeydown);
    };
  });
  </script>

          <!-- svelte-ignore a11y-click-events-have-key-events -->
          <!-- svelte-ignore a11y-no-noninteractive-element-interactions -->
          
<div class='layout'> 
  <div class='hero-and-titles' in:fade={{ delay: 500, duration: 1000, easing: elasticOut }}>
    <div class='hero'>
      <img 
        tabindex="0"
        src={images[activeImage]?.src} 
        alt={images[activeImage]?.title}
        on:keydown={handleKeydown}
        on:touchstart={handleTouchStart}
        on:touchmove={handleTouchMove}
      />
    </div>
    <div class='titles' in:fade={{ duration: 1000 }}>
      <p>{images[activeImage]?.title}</p>
      <p class='latin'>{images[activeImage]?.latinName}</p>
    </div>
  </div>
  <div class='thumbnail-frame'>
    <div class='thumbnails'>
      {#each images as image, i}
        <div class='thumbnail'>

          <img src={getThumbnailSrc(image.src)} alt={`Thumbnail of ${image.title}`} on:click={() => activeImage = i} />
        </div>
      {/each}
    </div>
  </div>
</div>


<style>
.layout {
  display: grid;
  grid-template-areas: 
    "hero thumbnails"
    "titles thumbnails";
  grid-template-columns: 1fr 248px;
  grid-template-rows: auto auto;
  height: 100vh; /* Set to viewport height */
}

.hero-and-titles {
  grid-area: hero;
  display: flex;
  flex-direction: column;
  justify-content: center;
  max-height: 100vh;
}
  .hero {
    display: flex;
    flex: 1;
    align-items: center;
    justify-content: center;
    width: 100%;
  }

  .hero img {
    object-fit: contain;
    max-width: 100%;
    max-height: 100%;
  }

  .titles {
    grid-area: titles;
    display: flex;
    justify-content: space-between;
    background-color: var(--color1) ;
    text-wrap: nowrap;
    align-self: center;
    font-family: 'Merriweather', serif;
    color: var(--color2);
    font-size: var(--a1);
    font-weight: 300;
    margin-top: var(--b);
    }
    
  .titles p {
    transition: fade-in 1s ease-in-out;
  margin-right: var(--d1); /* Space between titles */
  margin-left: var(--d1);  /* Space between titles */
}

  .latin {
    font-style: italic;
  }

  .thumbnail-frame {
    grid-area: thumbnails;
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    overflow-y: auto;
    max-height: 248px;
    padding: var(--b);
    scroll-behavior: smooth;
    scroll-snap-type: y mandatory;
  }

  .thumbnails {
    scroll-snap-type: y mandatory;
    flex-wrap: nowrap;  
    flex-shrink: 0;
    flex-grow: 0;
    }

  .thumbnail img {
    object-fit: cover;
    height: 80px;
    width: 80px;
    cursor: pointer;
    scroll-snap-align: start;
  }

  /* Add a media query for smaller screens */
@media (max-width: 768px) {

  .layout {
    grid-template-areas: 
      "hero"
      "titles"
      "thumbnails";
    grid-template-columns: 1fr;
    grid-template-rows: auto auto auto;
  }
  .hero-and-titles {
    max-width: 100%;
  }

  .hero img {
    display: flex;
    flex: 0 0 auto;
    height: 480px;
    max-width: 100%;
  }
  .thumbnail-frame {
    display: flex;
    max-width: 350px;
    flex-direction: row;
    overflow-x: auto;
    overflow-y: hidden;
    scroll-snap-type: x mandatory;
    align-items: center;
    justify-content: flex-start;
     }
  .thumbnails {
    gap: 4px;
    display: flex;
    flex-wrap: nowrap;
    align-items: center;
    justify-content: center;
    flex-direction: row;
    scroll-snap-type: x mandatory;
    overflow-x: auto;  /* Enable horizontal scrolling */
    overflow-y: hidden;  /* Disable vertical scrolling */
  }

  .thumbnail img{
    flex-shrink: 0;
    height: 80px;
    width: 80px;
  }

.titles {
    display: flex;
    align-items: center;
    font-family: var(--merri);
    font-size: var(--a1);
    font-weight: 300;
    color: var(--color2);
    /* opacity: 0; */
    transition: opacity 0.6s ease;
}
}

</style>