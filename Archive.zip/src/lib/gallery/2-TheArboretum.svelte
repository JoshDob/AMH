<script>
  import { arboretum } from "./galleries";
  import GalleryLayout from "./GalleryLayout.svelte";
</script>

<GalleryLayout images={arboretum} />